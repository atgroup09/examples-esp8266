# ESP8266 ESP-01 Ai Thinker

**SPI-FLASH**

- QUAD: 512KB/4Mbits

**Supported firmwares**

- ai-thinker-0.9.5.2-9600.bin
  - UART0.baudrate: 9600
  - flash start address: 0x00000
- ai-thinker-0.9.5.2-115200.bin
  - UART0.baudrate: 115200
  - flash start address: 0x00000

**Install firmware**

- Start flash_download_tool_3.9.5.exe
  - ChipType: ESP8266
  - WorkMode: Develop
  - LoadMode: UART
  - OK
- On ESP-01
  - GPIO0 > GND
  - RST > GND > 10K VCC or Free
- SPIDownload
  - [+][ ai-thinker-0.9.5.2-115200.bin   ][...]@ [0x00000  ]
  - SPI SPEED: 40MHz
  - SPI MODE:  QIO
  - [ ] DoNotChgBin
  - COM: COM? (see system device manager)
  - BAUD: 115200
  - START
